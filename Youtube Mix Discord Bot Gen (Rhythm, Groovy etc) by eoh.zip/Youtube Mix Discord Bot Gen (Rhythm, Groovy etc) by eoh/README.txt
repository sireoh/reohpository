# Youtube Mix Discord Bot Gen (Rhythm, Groovy etc) by eoh v1.0

Youtube Mix Discord Bot Gen is a generator that creates automixes for YouTube using 

## Installation

Extract the .zip and put it somewhere you'll remember.
Set default program as your default browser(Chrome, Firefox, Edge etc).

## Usage

Use online at [itch page link] or download for offline using Chrome, Firefox, Edge etc to run with.

Input the youtube URL
https://www.youtube.com/watch?v=*

Answer prompt
1 - Rhythm Bot
2 - Groovy Bot
3 - Manually

Output through alert box, or printed below(For browsers with unsupported copy/paste in alert boxes).

## License
[Itch](https://sireoh.itch.io/)
[Github](https://github.com/sireoh)
[Instagram](https://www.instagram.com/xsireoh)